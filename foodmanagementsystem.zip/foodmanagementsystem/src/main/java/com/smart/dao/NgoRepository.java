package com.smart.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smart.entities.Ngo;
public interface NgoRepository extends JpaRepository<Ngo,Integer>{
	

}


