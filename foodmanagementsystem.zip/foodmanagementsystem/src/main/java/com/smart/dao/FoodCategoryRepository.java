package com.smart.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smart.entities.Food_category;

public interface FoodCategoryRepository extends JpaRepository<Food_category,Integer>{
	
}