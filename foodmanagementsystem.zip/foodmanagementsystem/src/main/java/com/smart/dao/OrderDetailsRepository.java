package com.smart.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.smart.entities.Order_details;

public interface  OrderDetailsRepository extends JpaRepository <Order_details,Integer>{

}
