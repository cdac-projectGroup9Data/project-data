package com.smart.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smart.entities.Payment;

public interface PaymentRepository extends JpaRepository<Payment,Integer>{
	

}
