package com.smart.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import com.smart.entities.Delivery_person;

public interface  Delivery_personRepository extends JpaRepository<Delivery_person,Integer>{
	
}
