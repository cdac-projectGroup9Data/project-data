package com.smart.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smart.entities.Admin;

public interface AdminRepository extends JpaRepository<Admin,Integer> {
	

}
