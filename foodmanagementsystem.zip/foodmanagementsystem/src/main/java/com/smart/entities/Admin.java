package com.smart.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;

import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table (name="Admin")
public class Admin {
	
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	private int admin_id;
	
	private String full_name;
	
	@Column(length=50)
	private String admin_user_name;
	
	@Column(length=50)
	private String admin_password;
	
	@Column(length=10)
	private String contact;

	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY, mappedBy="admin")
	private List<Food_category> food_category=new ArrayList<>();
	
			
	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY, mappedBy="admin")
	private List<Ngo> ngo=new ArrayList<>();
	
	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY, mappedBy="admin")
	private List<Delivery_person> delivery_person=new ArrayList<>();
	
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public List<Ngo> getNgo() {
		return ngo;
	}

	public void setNgo(List<Ngo> ngo) {
		this.ngo = ngo;
	}
	

	public List<Food_category> getFood_category() {
		return food_category;
	}

	public void setFood_category(List<Food_category> food_category) {
		this.food_category = food_category;
	}

	
		public List<Delivery_person> getDelivery_person() {
		return delivery_person;
	}

	public void setDelivery_person(List<Delivery_person> delivery_person) {
		this.delivery_person = delivery_person;
	}

		public int getAdmin_id() {
		return admin_id;
	}

	public void setAdmin_id(int admin_id) {
		this.admin_id = admin_id;
	}

	public String getFull_name() {
		return full_name;
	}

	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}

	public String getAdmin_user_name() {
		return admin_user_name;
	}

	public void setAdmin_user_name(String admin_user_name) {
		this.admin_user_name = admin_user_name;
	}

	public String getAdmin_password() {
		return admin_password;
	}

	public void setAdmin_password(String admin_password) {
		this.admin_password = admin_password;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}
	
	
}
