package com.smart.entities;


import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import javax.persistence.Table;

@Entity
@Table (name="Ngo")
public class Ngo {
	
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		private int ngo_id;
		
		@Column(length=100)
		private String ngo_name;
		
		@Column(length=250)
		private String ngo_address;
		
		@Column(length=10)
		private String ngo_contact_number;
		
		@Column(length=20)
		private String ngo_link_date;
		
		@Column(length=25)
		private String current_status;

		//bidirectional mapping
		@ManyToOne
		private Admin admin;
				
		public Ngo() {
			super();
			// TODO Auto-generated constructor stub
		}

		public int getNgo_id() {
			return ngo_id;
		}

		public void setNgo_id(int ngo_id) {
			this.ngo_id = ngo_id;
		}

		public String getNgo_name() {
			return ngo_name;
		}

		public void setNgo_name(String ngo_name) {
			this.ngo_name = ngo_name;
		}

		public String getNgo_address() {
			return ngo_address;
		}

		public void setNgo_address(String ngo_address) {
			this.ngo_address = ngo_address;
		}

		public String getNgo_contact_number() {
			return ngo_contact_number;
		}

		public void setNgo_contact_number(String ngo_contact_number) {
			this.ngo_contact_number = ngo_contact_number;
		}

		public String getNgo_link_date() {
			return ngo_link_date;
		}

		public void setNgo_link_date(String ngo_link_date) {
			this.ngo_link_date = ngo_link_date;
		}

		public String getCurrent_status() {
			return current_status;
		}

		public void setCurrent_status(String current_status) {
			this.current_status = current_status;
		}
		public Admin getAdmin() {
			return admin;
		}

		public void setAdmin(Admin admin) {
			this.admin = admin;
		}
		
}
