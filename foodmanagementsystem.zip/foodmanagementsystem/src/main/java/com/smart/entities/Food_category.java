package com.smart.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;



@Entity
@Table(name="Food_category")
public class Food_category {

		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		private int food_category_id;
		
		@Column(length=100)
		private String food_category_name;
		@Column(length=100)
		private String description;
		@Column(length=50)
		private String current_status;
		
		//bidirectional mapping
		@ManyToOne		
		private Admin admin;
		
		@ManyToOne
		private Order_details order_Details;
		
		@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY, mappedBy="food_category")
		private List<Food_items> food_items=new ArrayList<>();
		
		public List<Food_items> getFood_items() {
			return food_items;
		}

		public void setFood_items(List<Food_items> food_items) {
			this.food_items = food_items;
		}

		public Admin getAdmin() {
			return admin;
		}

		public void setAdmin(Admin admin) {
			this.admin = admin;
		}

		public Order_details getOrder_Details() {
			return order_Details;
		}

		public void setOrder_Details(Order_details order_Details) {
			this.order_Details = order_Details;
		}

		public Admin getadmin() {
			return admin;
		}

		public void setadmin(Admin admin) {
			this.admin = admin;
		}

		
		public Food_category() {
			super();
			// TODO Auto-generated constructor stub
		}
		public int getFood_category_id() {
			return food_category_id;
		}
		public void setFood_category_id(int food_category_id) {
			this.food_category_id = food_category_id;
		}
		public String getFood_category_name() {
			return food_category_name;
		}
		public void setFood_category_name(String food_category_name) {
			this.food_category_name = food_category_name;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getCurrent_status() {
			return current_status;
		}
		public void setCurrent_status(String current_status) {
			this.current_status = current_status;
		}		
		
}
