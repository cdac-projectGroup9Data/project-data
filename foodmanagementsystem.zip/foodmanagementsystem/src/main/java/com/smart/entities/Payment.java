package com.smart.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table (name="Payment")
public class Payment {

		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		private int payment_id;
		private float payment_amount;
		
		@Column(length=15)
		private String payment_mode;
		
	
		@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY, mappedBy="payment")
		private List<Delivery_person> delivery_person=new ArrayList<>();

		//edited
		@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY, mappedBy="payment")
		private List<Order_details> order_details=new ArrayList<>();
		
		
		public Payment() {
			super();
			// TODO Auto-generated constructor stub
		}

		public int getPayment_id() {
			return payment_id;
		}

		public void setPayment_id(int payment_id) {
			this.payment_id = payment_id;
		}

		public float getPayment_amount() {
			return payment_amount;
		}

		public void setPayment_amount(float payment_amount) {
			this.payment_amount = payment_amount;
		}

		public String getPayment_mode() {
			return payment_mode;
		}

		public void setPayment_mode(String payment_mode) {
			this.payment_mode = payment_mode;
		}
		public List<Delivery_person> getDelivery_person() {
			return delivery_person;
		}

		public void setDelivery_person(List<Delivery_person> delivery_person) {
			this.delivery_person = delivery_person;
		}
		
		//
		public List<Order_details> getorder_details() {
			return order_details;
		}

		public void setOrder_details(List<Order_details> order_details) {
			this.order_details = order_details;
		}
				
}