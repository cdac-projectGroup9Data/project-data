package com.smart.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table (name="food_items")
public class Food_items {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int food_item_id;
	
	@Column(length=100)
	private String food_item_name;
	
	@Column(length=150)
	private String description;
	
	private float price;

	private int quantity;

	@ManyToOne
	private Admin admin;
	
	@ManyToOne
	private Food_category food_category;
	
	@ManyToOne
	private Order_details order_details;
	
	public Order_details getOrder_details() {
		return order_details;
	}


	public void setOrder_details(Order_details order_details) {
		this.order_details = order_details;
	}


	public Food_category getFood_category() {
		return food_category;
	}


	public void setFood_category(Food_category food_category) {
		this.food_category = food_category;
	}


	public Food_items() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	public int getFood_item_id() {
		return food_item_id;
	}

	public void setFood_item_id(int food_item_id) {
		this.food_item_id = food_item_id;
	}

	public String getFood_item_name() {
		return food_item_name;
	}

	public void setFood_item_name(String food_item_name) {
		this.food_item_name = food_item_name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	
	
}
