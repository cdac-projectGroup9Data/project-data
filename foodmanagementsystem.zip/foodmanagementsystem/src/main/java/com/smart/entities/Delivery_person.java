package com.smart.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Column;
@Entity
@Table (name="Delivery_person")
public class Delivery_person {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int delivery_person_id;
	
	@Column(length=100)
	private String full_name;
	@Column(length=50)
	private String username;
	@Column(length=50)
	private String password;
	
	@Column(length=10)
	private String contact;

	//bidirectional mapping
	@ManyToOne
	private Admin admin;
	
	//bidirectional mapping
	@ManyToOne
	private Payment payment;
			
	//bidirectional mapping
	@ManyToOne
	private Order_details order_details;
				
		
	public Delivery_person() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getDelivery_person_id() {
		return delivery_person_id;
	}

	public void setDelivery_person_id(int delivery_person_id) {
		this.delivery_person_id = delivery_person_id;
	}

	public String getFull_name() {
		return full_name;
	}

	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	public Payment getPayment() {
		return payment;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}

	public Order_details getOrder_details() {
		return order_details;
	}

	public void setOrder_details(Order_details order_details) {
		this.order_details = order_details;
	}

	public void save(Delivery_person delivery_personn) {
		// TODO Auto-generated method stub
		
	}

	

}
