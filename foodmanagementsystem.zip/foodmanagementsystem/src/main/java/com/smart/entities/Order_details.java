package com.smart.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table (name="Order_details")
public class Order_details {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int order_id;
		

	@Column(length=50)
	private String food_item_name;
	
	private int quantities;
	
	private float price;

	private float total_final_amount;
	
	@Column(length=250)
	private String delivery_address;

	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY, mappedBy="order_details")
	private List<Food_items> food_items=new ArrayList<>();
	
	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY, mappedBy="order_details")
	private List<Delivery_person> delivery_person=new ArrayList<>();
	//bidirectional mapping
	
	@ManyToOne
	private User user;
	
	//bidirectional mapping
	@ManyToOne
	private Payment payment;
		
	
	public Order_details() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getOrder_id() {
		return order_id;
	}

	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}


	public String getFood_item_name() {
		return food_item_name;
	}

	public void setFood_item_name(String food_item_name) {
		this.food_item_name = food_item_name;
	}

	public int getQuantities() {
		return quantities;
	}

	public void setQuantities(int quantities) {
		this.quantities = quantities;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public float getTotal_final_amount() {
		return total_final_amount;
	}

	public void setTotal_final_amount(float total_final_amount) {
		this.total_final_amount = total_final_amount;
	}

	public String getDelivery_address() {
		return delivery_address;
	}

	public void setDelivery_address(String delivery_address) {
		this.delivery_address = delivery_address;
	}

	public List<Food_items> getFood_items() {
		return food_items;
	}

	public void setFood_items(List<Food_items> food_items) {
		this.food_items = food_items;
	}

	public List<Delivery_person> getDelivery_person() {
		return delivery_person;
	}

	public void setDelivery_person(List<Delivery_person> delivery_person) {
		this.delivery_person = delivery_person;
	}
	public void setUser(User user) {
		this.user= user;
	}
	
	public void setPayment(Payment payment) {
		this.payment = payment;
	}
	

	
}
