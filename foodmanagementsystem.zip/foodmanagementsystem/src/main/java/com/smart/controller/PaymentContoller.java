package com.smart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smart.entities.Payment;
import com.smart.dao.PaymentRepository;

@Controller
public class PaymentContoller {

	@Autowired
	private PaymentRepository paymentRepository;
	@GetMapping("/payment")
	@ResponseBody
	public String test()
	{
		
		Payment payment = new Payment();
		payment.setOrder_details(null);
		payment.setPayment_amount(688);
		payment.setPayment_mode("cash");
		paymentRepository.save(payment);
		return "Payment module working successfully";
	}
}
