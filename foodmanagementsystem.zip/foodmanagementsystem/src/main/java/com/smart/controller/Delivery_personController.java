package com.smart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smart.dao.Delivery_personRepository;
import com.smart.entities.Delivery_person;
@Controller
public class Delivery_personController {

	
	@Autowired
	private Delivery_personRepository delivery_personRepository;
	
	@GetMapping("/deliveryperson")
	@ResponseBody

	public String test()
	{
		
		Delivery_person delivery_personn = new Delivery_person();
		delivery_personn.setFull_name("Mr. Arick Johnson");
		delivery_personn.setUsername("DID1288");
		delivery_personn.setPassword("DID12345");		
		delivery_personn.setContact("9524840566");
		delivery_personn.setAdmin(null);
		delivery_personn.setPayment(null);
		delivery_personn.setOrder_details(null);
		
		delivery_personRepository.save(delivery_personn);
		return "Delivery person module working successfully";
	}
}
