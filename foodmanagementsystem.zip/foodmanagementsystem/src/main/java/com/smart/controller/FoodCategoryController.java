package com.smart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smart.dao.FoodCategoryRepository;
import com.smart.entities.Food_category;

@Controller
public class FoodCategoryController {

	@Autowired
	private FoodCategoryRepository FoodCategoryRepository;
	
	@GetMapping("/foodcategory")
	@ResponseBody
	public String test()
	{
		
		Food_category food_category= new Food_category();
		
		food_category.setFood_category_name("Tea");
		food_category.setDescription("Vegan");
		food_category.setCurrent_status("Available");
		food_category.setadmin(null);
		
		FoodCategoryRepository.save(food_category);
		return "Food category working successfully";
	}
}
