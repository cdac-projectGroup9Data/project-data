package com.smart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smart.dao.OrderDetailsRepository;
import com.smart.entities.Order_details;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;



@SpringBootApplication
@ComponentScan(basePackages= {"com.smart.controller"})
@Controller
public class OrderDetailsController {


	@Autowired
	private  OrderDetailsRepository order_detailsRepository;
	
	@GetMapping("/order")
	@ResponseBody
	public String test()
	{
		
		Order_details order_details = new Order_details ();
		order_details.setFood_item_name("Matcha Green Tea with honey");
		order_details.setQuantities(4);
		order_details.setPrice(167);
		order_details.setTotal_final_amount(668);
		order_details.setDelivery_address("Phule Villa , no 817, near empire garden, Kothrud, Pune 411035");
		order_details.setFood_items(null);
		order_details.setDelivery_person(null);
		order_details.setPayment(null);
	
		order_detailsRepository.save(order_details);
		return "Order_Details module working successfully";
	}
	
}

