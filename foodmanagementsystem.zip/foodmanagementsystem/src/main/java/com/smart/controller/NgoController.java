package com.smart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;


import com.smart.dao.NgoRepository;

import com.smart.entities.Ngo;


@Controller
public class NgoController {

	@Autowired
	private NgoRepository ngoRepository;
	
	@GetMapping("/ngoo")
	@ResponseBody
	public String test()
	{
		
		Ngo ngo = new Ngo();
		
		ngo.setNgo_name("womens foundation");		
		ngo.setNgo_address("abcd road");
		ngo.setNgo_link_date("8thmarch2022");
		ngo.setCurrent_status("active");
		ngo.setNgo_contact_number("952774370");
		ngo.setAdmin(null);	
		ngoRepository.save(ngo);
		return "NGO module working successfully";
	}
	
}

