package com.smart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smart.dao.AdminRepository;
import com.smart.entities.Admin;


@Controller
public class AdminController {

	@Autowired
	private AdminRepository adminRepository;
	@GetMapping("/admin")
	@ResponseBody
	public String test()
	{
		
		Admin admin = new Admin();
		admin.setAdmin_id(121);
		admin.setAdmin_password("admin@1234");
		admin.setAdmin_user_name("Admin_Jennie");
		admin.setFull_name("Jennie Ruby Jane");
		admin.setContact("9890915822");
	
		adminRepository.save(admin);
		return "Admin module working successfully";
	}
}
