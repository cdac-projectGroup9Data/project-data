package com.smart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smart.entities.User;
import com.smart.dao.UserRepository;

@Controller
public class UserContoller {

	@Autowired
	private UserRepository userRepository;
	@GetMapping("/user")
	@ResponseBody
	public String test()
	{
		
		User user = new User();
		user.setFirst_name("Lay");
		user.setLast_name("Zhang");
		user.setEmail("chromosomeentertainmentollsfqawl@gmail.com");
		user.setPhone_number("9527743700");
		user.setUser_address("Villa no 99, near ornaldo park, Changsha, China 4328891");
		user.setUsername("orion-star-seed");
		user.setPassword("$Ss03312764");
		
		userRepository.save(user);
		return "User module working successfully";
	}
}
