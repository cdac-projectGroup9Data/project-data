package com.smart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smart.dao.FoodItemsRepository;
import com.smart.entities.Food_items;

@Controller
public class FoodItemsController {

	@Autowired
	private FoodItemsRepository fooditemsRepository;

	@GetMapping("/fooditems")
	@ResponseBody
	public String test()
	{
		Food_items  food_items =new Food_items ();
		food_items.setFood_item_name("Matcha green tea with honey");
		food_items.setDescription("export quality matcha with non preservatives");
		food_items.setPrice(157);
		food_items.setQuantity(4);
		food_items.setAdmin(null);
		food_items.setFood_category(null);

		
		fooditemsRepository.save(food_items);
		return "food items module working successfully";
	}
	
}

