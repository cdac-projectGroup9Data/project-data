package com.smart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartFoodOrderManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
